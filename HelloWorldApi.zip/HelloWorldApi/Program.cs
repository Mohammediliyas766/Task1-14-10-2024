using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Hello World!\n It's Mohammed Iliyas Coding on .Net\n Happy Coding:)");

app.Run();
